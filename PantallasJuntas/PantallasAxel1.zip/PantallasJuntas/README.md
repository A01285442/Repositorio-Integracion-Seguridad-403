# Repositorio-Integracion-Seguridad-403

Este repositorio es para el desarrollo de un proyecto el cual consisite en una app para la divulgación y gestión de situaciones con necesidades legales, que permita a los usuarios reconocer y abordar sus problemas legales de manera eficiente y segura. La aplicación ofrecerá acceso a información relevante, facilitará la solicitud de asesoría y la clasificación de problemas legales en categorías específicas. Esta aplicacion es un solitcitud de la Clinica Penal del Tecnologico de Monterrey.
