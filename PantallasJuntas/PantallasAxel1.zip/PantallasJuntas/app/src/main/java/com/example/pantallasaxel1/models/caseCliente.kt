package com.example.pantallasaxel1.models


data class caseCliente(
    val title: String,
    val date: String,
    val description: String
)
